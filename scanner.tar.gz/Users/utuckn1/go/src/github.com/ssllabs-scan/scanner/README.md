# How To Use the Scanner
* First, compile the go binary with go build ssllabs-scan-v3.go
* Next, run scanner.py with $python3 scanner.py
* You will be prompted to enter in different flags. For grade output, enter G
* Then, specify a file of hosts. I have included an empty "hosts.txt"
* Once the scan has completed, just run the grader.py and it will say which IP's have failed